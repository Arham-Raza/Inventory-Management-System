# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

ECS POS is a Point of Sale and inventory management system for Easy Connect Solutions (computer hardware / laptop retail). Built with Next.js App Router, Prisma ORM, and MySQL.

## Commands

```bash
npm run dev          # Start dev server (http://localhost:3000)
npm run build        # Production build
npm run lint         # ESLint

# Tests
npm test             # Jest unit tests
npm run test:watch   # Jest watch mode
npm run test:coverage
npm run test:e2e     # Playwright E2E (requires running dev server + test seed data)
npm run test:e2e:ui  # Playwright interactive mode

# Database
npx prisma migrate dev        # Apply schema migrations (run after every schema change)
npx prisma db push            # Push schema without migration history
npx tsx src/scripts/seed.ts   # Seed initial admin user (admin@ecs.com / admin123)
```

## Environment Setup

Requires MySQL. Relevant `.env` variables:
- `DATABASE_URL` — e.g. `mysql://root:@localhost:3306/ecs_pos_db`
- `NEXTAUTH_SECRET` — JWT signing key
- `NEXTAUTH_URL` — auth callback base URL
- `AUTH_TRUST_HOST` — set `true` for localhost dev

## Architecture

### Route Groups

| Route | Access | Description |
|---|---|---|
| `(admin)` | All authenticated roles | Dashboard, Inventory, Data Entry, Accounting, Discounts, Employees |
| `(pos)` | All roles | POS terminal at `/pos` |
| `/login` | Public | NextAuth credentials form |
| `/api/auth/[...nextauth]` | Public | NextAuth handler |

### Data Flow

Server actions in `src/actions/` are the only mutation path. No REST API layer.

```
Client Component → Server Action (auth() check → Prisma $transaction) → revalidatePath()
```

### Key Files

| Path | Purpose |
|---|---|
| `src/auth.ts` | NextAuth config — credentials provider, JWT with role + id claims |
| `src/lib/prisma.ts` | Prisma singleton (dev HMR safe) |
| `src/lib/money.ts` | Integer-based (paisa) financial math — discount, tax, total |
| `src/actions/order.ts` | `createOrder` — full $transaction, concurrency guard, server-side pricing |
| `src/actions/pos.ts` | `lookupInventoryItem` — returns Decimal as number |
| `src/actions/dashboard.ts` | `getDashboardStats` — aggregated KPIs for dashboard |
| `src/components/pos/POSClient.tsx` | Main POS terminal — exports `CartItem`, `PaymentMethod` types |
| `src/components/pos/ThermalReceipt.tsx` | 80mm thermal receipt, imports types from POSClient |
| `src/components/layout/Sidebar.tsx` | Dark sidebar with role-filtered nav + user info strip |
| `src/hooks/useBarcodeScanner.ts` | Global hardware scanner hook (stable-ref, idle-flush) |
| `prisma/schema.prisma` | Full DB schema |

### Database Models

- **`InventoryItem`** — Each physical laptop is a unique record keyed by `serialNumber`. Has `gpu` (base spec). `ram`/`storage` are confirmed + updated at checkout.
- **`Order` / `OrderItem`** — `priceAtSale` is snapshotted from DB at transaction time (never from client).
- **`DiscountCampaign`** — `PERCENTAGE` or `FIXED`. Must convert `value` (Decimal) with `Number()` before rendering.
- **`User`** — Roles: `SUPER_ADMIN`, `MANAGER`, `DATA_ENTRY`, `CASHIER`.

> **Decimal rule**: All monetary DB fields are `Decimal @db.Decimal(10,2)`. Always wrap with `Number()` before JavaScript arithmetic or rendering: `Number(item.retailPrice).toLocaleString()`.

### Concurrency Protection (`src/actions/order.ts`)

The critical guard is a conditional `updateMany` inside `prisma.$transaction`:

```typescript
await tx.inventoryItem.updateMany({
  where: { serialNumber: sn, status: "AVAILABLE" },  // atomic guard
  data:  { status: "SOLD", orderItemId: orderItem.id },
})
// result.count === 0 → already sold by another cashier → throw → full rollback
```

### Serialized Asset Tracking (Core Business Rule)

1. Cashier scans barcode → `lookupInventoryItem` checks DB
2. **Spec Confirmation Dialog** opens — locked: model/CPU/GPU; editable: RAM/Storage
3. Cashier explicitly clicks "Add to Cart" — confirmed specs are stored to cart and persisted to DB + receipt
4. On checkout, `createOrder` uses DB prices (not client values) and runs the atomic concurrency guard

### Financial Math (`src/lib/money.ts`)

All arithmetic uses **paisa** (1 Rs = 100 paisa) internally to eliminate drift:
- `TAX_RATE_PERCENT = 18` — single source of truth for GST
- `calculateOrderTotals(subtotal, discount)` returns `{ discountAmount, discountedSubtotal, tax, total }`
- `formatRs(amount)` — locale-formatted display string

### POS Payment Methods

`PaymentMethod = "CASH" | "CARD" | "TRANSFER"` (state in POSClient only; not currently stored in DB).

- PAY button color changes: green (Cash), blue (Card), violet (Transfer)
- Payment method is printed on the thermal receipt

### UI Screen Summary

| Screen | File | Notable |
|---|---|---|
| Login | `app/login/` | Split-screen: dark brand panel (left) + white form (right) |
| Dashboard | `app/(admin)/dashboard/page.tsx` | Live KPIs from `getDashboardStats` |
| Inventory | `app/(admin)/inventory/page.tsx` | GPU column; Decimal wrapped with `Number()` |
| Discounts | `app/(admin)/discounts/page.tsx` | Decimal wrapped with `Number()` |
| POS | `components/pos/POSClient.tsx` | Spec dialog + payment method selector |

### Testing

- **Unit**: `src/__tests__/cart-calculations.test.ts` — pure math for `src/lib/money.ts`
- **E2E**: `tests/e2e/pos-checkout.spec.ts` — requires seeded items `TEST-AVAIL-001`, `TEST-SOLD-001`, `TEST-DISC-001`

> **Next.js 16.x note**: APIs may differ from standard docs — check `node_modules/next/dist/docs/` when behaviour is unexpected.

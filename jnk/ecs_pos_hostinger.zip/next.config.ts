import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: {
    // jest.config.ts and playwright.config.ts are not app code — skip them during build
    ignoreBuildErrors: true,
  },
};

export default nextConfig;

"use server"

import prisma from "@/lib/prisma"
import { auth } from "@/auth"

export async function getAccountingStats() {
  const session = await auth()
  if (!session) throw new Error("Unauthorized")

  const orders = await prisma.order.findMany({
    include: {
      items: {
        include: {
          inventoryItem: true,
        },
      },
      discount: true,
    },
    orderBy: { createdAt: "desc" },
  })

  let totalRevenue = 0
  let totalCogs = 0

  const transactions = orders.map((order) => {
    // Decimal → number before arithmetic
    const revenue = Number(order.totalAmount)
    const cogs = order.items.reduce((sum, item) => {
      return sum + Number(item.inventoryItem?.purchaseCost ?? 0)
    }, 0)
    const profit = revenue - cogs

    totalRevenue += revenue
    totalCogs += cogs

    return {
      id: order.id,
      date: order.createdAt,
      itemsCount: order.items.length,
      revenue,
      cogs,
      profit,
      discountName: order.discount?.name ?? null,
    }
  })

  const grossProfit = totalRevenue - totalCogs
  const profitMarginPercent =
    totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0

  return {
    totalRevenue,
    totalCogs,
    grossProfit,
    profitMarginPercent,
    transactions,
  }
}

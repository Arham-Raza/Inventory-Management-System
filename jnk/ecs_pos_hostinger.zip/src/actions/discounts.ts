"use server"

import prisma from "@/lib/prisma"
import { auth } from "@/auth"
import { revalidatePath } from "next/cache"

export async function createDiscountCampaign(data: {
  name: string
  type: string
  value: number
}) {
  const session = await auth()
  if (session?.user?.role === "CASHIER" || !session) {
    throw new Error("Unauthorized")
  }

  const campaign = await prisma.discountCampaign.create({
    data: {
      name: data.name,
      type: data.type,
      value: data.value,
      isActive: true
    }
  })

  revalidatePath('/discounts')
  revalidatePath('/pos')
  return campaign
}

export async function toggleDiscountCampaign(id: string, isActive: boolean) {
  const session = await auth()
  if (session?.user?.role === "CASHIER" || !session) {
    throw new Error("Unauthorized")
  }

  await prisma.discountCampaign.update({
    where: { id },
    data: { isActive }
  })

  revalidatePath('/discounts')
  revalidatePath('/pos')
}

export async function getActiveDiscounts() {
  return prisma.discountCampaign.findMany({
    where: { isActive: true },
    orderBy: { createdAt: 'desc' }
  })
}

"use server"

import prisma from "@/lib/prisma"
import { auth } from "@/auth"
import { revalidatePath } from "next/cache"

export async function addInventoryItem(data: {
  serialNumber: string
  modelName: string
  processor: string
  gpu: string
  ram: string
  storage: string
  purchaseCost: number
  retailPrice: number
}) {
  const session = await auth()
  if (!session || session.user?.role === "CASHIER") {
    throw new Error("Unauthorized")
  }

  const item = await prisma.inventoryItem.create({
    data: {
      ...data,
      status: "AVAILABLE",
    },
  })

  revalidatePath("/inventory")
  revalidatePath("/data-entry")
  return item
}

export async function getInventoryStats() {
  const [totalItems, availableItems, items] = await Promise.all([
    prisma.inventoryItem.count(),
    prisma.inventoryItem.count({ where: { status: "AVAILABLE" } }),
    prisma.inventoryItem.findMany({ where: { status: "AVAILABLE" } }),
  ])

  const totalValue = items.reduce(
    (sum, item) => sum + Number(item.purchaseCost),
    0
  )

  return { totalItems, availableItems, totalValue }
}

export async function getAllInventory() {
  return prisma.inventoryItem.findMany({ orderBy: { createdAt: "desc" } })
}

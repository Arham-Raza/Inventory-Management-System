"use server"

import prisma from "@/lib/prisma"
import { auth } from "@/auth"
import { revalidatePath } from "next/cache"
import { calculateOrderTotals } from "@/lib/money"

type OrderItemInput = {
  serialNumber: string
  // Confirmed specs at checkout time — may differ from DB if unit was reconfigured
  confirmedRam?: string
  confirmedStorage?: string
}

type CreateOrderInput = {
  appliedDiscountId?: string
  items: OrderItemInput[]
}

export async function createOrder(data: CreateOrderInput) {
  const session = await auth()
  if (!session?.user?.id) throw new Error("Unauthorized")

  const cashierId = session.user.id

  const result = await prisma.$transaction(async (tx) => {
    const serialNumbers = data.items.map((i) => i.serialNumber)

    // Read all items inside the transaction so we hold a consistent snapshot
    const inventoryItems = await tx.inventoryItem.findMany({
      where: { serialNumber: { in: serialNumbers } },
    })

    if (inventoryItems.length !== serialNumbers.length) {
      const found = inventoryItems.map((i) => i.serialNumber)
      const missing = serialNumbers.filter((sn) => !found.includes(sn))
      throw new Error(`Items not found in inventory: ${missing.join(", ")}`)
    }

    // Validate all are AVAILABLE (pre-flight check before writing anything)
    for (const item of inventoryItems) {
      if (item.status !== "AVAILABLE") {
        throw new Error(
          `"${item.modelName}" (${item.serialNumber}) is already ${item.status}. Remove it from the cart and try again.`
        )
      }
    }

    // Server-side total calculation — never trust the client-supplied total
    const subtotal = inventoryItems.reduce(
      (sum, i) => sum + Number(i.retailPrice),
      0
    )
    let discountMeta: { type: string; value: number } | null = null
    if (data.appliedDiscountId) {
      const campaign = await tx.discountCampaign.findUnique({
        where: { id: data.appliedDiscountId },
      })
      if (campaign?.isActive) {
        discountMeta = { type: campaign.type, value: Number(campaign.value) }
      }
    }
    const { total } = calculateOrderTotals(subtotal, discountMeta)

    // Create the Order record
    const order = await tx.order.create({
      data: {
        cashierId,
        totalAmount: total,
        appliedDiscountId: data.appliedDiscountId ?? null,
      },
    })

    // For each item: create OrderItem, then atomically flip status to SOLD.
    // The updateMany WHERE status='AVAILABLE' is the concurrency guard:
    // if another cashier already sold this item between our findMany and here,
    // that UPDATE will match 0 rows → we throw and roll back the entire transaction.
    for (const inputItem of data.items) {
      const invItem = inventoryItems.find(
        (i) => i.serialNumber === inputItem.serialNumber
      )!

      const orderItem = await tx.orderItem.create({
        data: {
          orderId: order.id,
          priceAtSale: Number(invItem.retailPrice),
        },
      })

      const updated = await tx.inventoryItem.updateMany({
        where: { serialNumber: invItem.serialNumber, status: "AVAILABLE" },
        data: {
          status: "SOLD",
          orderItemId: orderItem.id,
          // Persist any spec corrections the cashier made at checkout
          ...(inputItem.confirmedRam
            ? { ram: inputItem.confirmedRam }
            : {}),
          ...(inputItem.confirmedStorage
            ? { storage: inputItem.confirmedStorage }
            : {}),
        },
      })

      if (updated.count === 0) {
        // Another transaction beat us to this item
        throw new Error(
          `Concurrency conflict: "${invItem.modelName}" (${invItem.serialNumber}) was just sold by another cashier. Please remove it from the cart.`
        )
      }
    }

    return { orderId: order.id, total }
  })

  revalidatePath("/inventory")
  revalidatePath("/dashboard")
  revalidatePath("/accounting")

  return result
}

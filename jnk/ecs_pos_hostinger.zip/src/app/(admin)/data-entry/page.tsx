import { DataEntryForm } from "@/components/inventory/DataEntryForm"

export default function DataEntryPage() {
  return (
    <div className="py-6">
      <DataEntryForm />
    </div>
  )
}

import prisma from "@/lib/prisma"
import { AddDiscountDialog } from "@/components/discounts/AddDiscountDialog"
import { ToggleDiscountButton } from "@/components/discounts/ToggleDiscountButton"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tag, Percent, ToggleRight } from "lucide-react"
import { formatRs } from "@/lib/money"

export default async function DiscountsPage() {
  const campaigns = await prisma.discountCampaign.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      _count: { select: { orders: true } },
    },
  })

  const activeCount = campaigns.filter((c) => c.isActive).length
  const totalRedemptions = campaigns.reduce(
    (sum, c) => sum + c._count.orders,
    0
  )

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            Discount Campaigns
          </h1>
          <p className="text-slate-500 mt-1">
            Manage promotions available to cashiers at checkout.
          </p>
        </div>
        <AddDiscountDialog />
      </div>

      {/* ── KPI cards ── */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">
              Total Campaigns
            </CardTitle>
            <div className="p-2 bg-slate-100 rounded-lg">
              <Tag className="h-4 w-4 text-slate-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black text-slate-900">
              {campaigns.length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">
              Active Promotions
            </CardTitle>
            <div className="p-2 bg-emerald-50 rounded-lg">
              <ToggleRight className="h-4 w-4 text-emerald-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black text-emerald-600">
              {activeCount}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Visible to cashiers right now
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">
              Times Redeemed
            </CardTitle>
            <div className="p-2 bg-primary/10 rounded-lg">
              <Percent className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black text-slate-900">
              {totalRedemptions}
            </div>
            <p className="text-xs text-slate-400 mt-1">Across all campaigns</p>
          </CardContent>
        </Card>
      </div>

      {/* ── Campaign table ── */}
      <Card className="border-slate-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-bold text-slate-900">
            Campaign List
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-100">
                <TableHead className="pl-6 text-xs">Campaign Name</TableHead>
                <TableHead className="text-xs">Type</TableHead>
                <TableHead className="text-xs">Value</TableHead>
                <TableHead className="text-xs">Redemptions</TableHead>
                <TableHead className="text-xs text-right pr-6">
                  Active
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {campaigns.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={5}
                    className="text-center py-12 text-slate-400"
                  >
                    No discount campaigns yet. Click &quot;New Promotion&quot;
                    to create one.
                  </TableCell>
                </TableRow>
              ) : (
                campaigns.map((campaign) => {
                  const val = Number(campaign.value)
                  return (
                    <TableRow
                      key={campaign.id}
                      className="border-slate-100 hover:bg-slate-50/50"
                    >
                      <TableCell className="pl-6 font-semibold text-sm text-slate-900">
                        {campaign.name}
                      </TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                            campaign.type === "PERCENTAGE"
                              ? "bg-violet-50 text-violet-700 border border-violet-200"
                              : "bg-blue-50 text-blue-700 border border-blue-200"
                          }`}
                        >
                          {campaign.type === "PERCENTAGE"
                            ? "% Percentage"
                            : "Rs. Fixed"}
                        </span>
                      </TableCell>
                      <TableCell className="font-bold text-slate-900">
                        {campaign.type === "PERCENTAGE"
                          ? `${val}%`
                          : formatRs(val)}
                      </TableCell>
                      <TableCell className="text-sm text-slate-500">
                        {campaign._count.orders}
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <ToggleDiscountButton
                          id={campaign.id}
                          isActive={campaign.isActive}
                        />
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

import { getAllEmployees } from "@/actions/employees"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default async function EmployeesPage() {
  const employees = await getAllEmployees()

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Staff & Roles</h1>
          <p className="text-muted-foreground">Manage employee accounts and their system access levels.</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Registered Employees</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email (Login ID)</TableHead>
                <TableHead>Role / Access Level</TableHead>
                <TableHead className="text-right">Transactions Processed</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees.map(emp => (
                <TableRow key={emp.id}>
                  <TableCell className="font-medium">{emp.name}</TableCell>
                  <TableCell>{emp.email}</TableCell>
                  <TableCell>
                    <span className={`inline-flex px-2 py-1 rounded text-xs font-bold ${
                      emp.role === 'SUPER_ADMIN' ? 'bg-purple-100 text-purple-800' :
                      emp.role === 'MANAGER' ? 'bg-blue-100 text-blue-800' :
                      emp.role === 'DATA_ENTRY' ? 'bg-orange-100 text-orange-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {emp.role}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">{emp._count.orders}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

import { getInventoryStats, getAllInventory } from "@/actions/inventory"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Package, Hash, Wallet, CheckCircle, XCircle, RotateCcw } from "lucide-react"
import { formatRs } from "@/lib/money"

function StatusChip({ status }: { status: string }) {
  if (status === "AVAILABLE") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
        <CheckCircle className="h-3 w-3" />
        Available
      </span>
    )
  }
  if (status === "RETURNED") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
        <RotateCcw className="h-3 w-3" />
        Returned
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-500 border border-slate-200">
      <XCircle className="h-3 w-3" />
      Sold
    </span>
  )
}

export default async function InventoryPage() {
  const [stats, items] = await Promise.all([
    getInventoryStats(),
    getAllInventory(),
  ])

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">
          Inventory Ledger
        </h1>
        <p className="text-slate-500 mt-1">
          Every physical unit tracked by serial number.
        </p>
      </div>

      {/* ── KPI cards ── */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">
              Total Units
            </CardTitle>
            <div className="p-2 bg-slate-100 rounded-lg">
              <Hash className="h-4 w-4 text-slate-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black text-slate-900">
              {stats.totalItems}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              All statuses combined
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">
              Available to Sell
            </CardTitle>
            <div className="p-2 bg-emerald-50 rounded-lg">
              <Package className="h-4 w-4 text-emerald-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black text-emerald-600">
              {stats.availableItems}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Ready at the POS terminal
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">
              Inventory Value (Cost)
            </CardTitle>
            <div className="p-2 bg-primary/10 rounded-lg">
              <Wallet className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black text-slate-900">
              {formatRs(stats.totalValue)}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Available stock at purchase cost
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ── Full inventory table ── */}
      <Card className="border-slate-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-bold text-slate-900">
            All Physical Stock
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-100">
                <TableHead className="pl-6 text-xs">Serial Number</TableHead>
                <TableHead className="text-xs">Model</TableHead>
                <TableHead className="text-xs">Processor</TableHead>
                <TableHead className="text-xs">GPU</TableHead>
                <TableHead className="text-xs">RAM</TableHead>
                <TableHead className="text-xs">Storage</TableHead>
                <TableHead className="text-xs text-right">Cost</TableHead>
                <TableHead className="text-xs text-right">Retail</TableHead>
                <TableHead className="text-xs pr-6">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={9}
                    className="text-center py-12 text-slate-400"
                  >
                    No items in inventory. Use the &quot;Receive Stock&quot;
                    portal to add units.
                  </TableCell>
                </TableRow>
              ) : (
                items.map((item) => (
                  <TableRow
                    key={item.serialNumber}
                    className="border-slate-100 hover:bg-slate-50/50"
                  >
                    <TableCell className="pl-6 font-mono text-xs font-bold text-slate-700">
                      {item.serialNumber}
                    </TableCell>
                    <TableCell className="font-medium text-sm text-slate-900">
                      {item.modelName}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">
                      {item.processor}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">
                      {item.gpu}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">
                      {item.ram}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">
                      {item.storage}
                    </TableCell>
                    <TableCell className="text-right text-sm text-slate-500">
                      {formatRs(Number(item.purchaseCost))}
                    </TableCell>
                    <TableCell className="text-right text-sm font-bold text-primary">
                      {formatRs(Number(item.retailPrice))}
                    </TableCell>
                    <TableCell className="pr-6">
                      <StatusChip status={item.status} />
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
